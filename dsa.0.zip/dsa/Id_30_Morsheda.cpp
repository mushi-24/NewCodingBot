
#include <iostream>
using namespace std;

int main() {

    int arr1[] = {1, 2, 3, 4, 5};
    int arr2[] = {6, 7, 8};
    int n1 = 5, n2 = 3;
    int merged_array[n1 + n2];

    int i = 0, j = 0, k = 0;
    while (i < n1 && j < n2) {
        if (arr1[i] < arr2[j]) {
            merged_array[k] = arr1[i];
            i++;
            k++;
        } else {
            merged_array[k] = arr2[j];
            j++;
            k++;
        }}
    while (i < n1) {
        merged_array[k] = arr1[i];
        i++;
        k++;}
    while (j < n2) {
        merged_array[k] = arr2[j];
        j++;
        k++;}
    cout << "Merged array in descending order: ";
    for (int x = n1 + n2 - 1; x >= 0; x--) {
        cout << merged_array[x] << " ";
    }
    cout << endl;

    return 0;
}
