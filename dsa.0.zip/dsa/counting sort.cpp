

 #include <iostream>
using namespace std;











int main() {

    int maxitei};
    int n = 6;

    for (int i = 1; i < n; i++) {
        if (scores[i] > maxitem) {
            maxitem = item[i]; //
            maxIndex = i;
        }
        for output n ;
         for int i=0;i<n;i++
            output [ count ara[i(i-1)=ara[i];
         count [ara[i]]--;
         cout<<"sorted array:";"
         for (int i=0;i<n;i++){
            cout << output[i]<<"";
         }
