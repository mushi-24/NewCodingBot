
#include <iostream>
using namespace std;

int main() {

    int bookIDs[] = {1, 2, 3, 3};
    string bookNames[] = {"C Programming", "Algorithm", "DSA1", "DSA2"};

    int n = 4;

    cout << "Original List:" << endl;
    for (int i = 0; i < n; i++) {
        cout << bookIDs[i] << " - " << bookNames[i] << endl;
    }

    // Remove duplicates
    int j = 0; // index for unique elements
    for (int i = 0; i < n - 1; i++) {
        if (bookIDs[i] != bookIDs[i + 1]) {
            bookIDs[j] = bookIDs[i];
            bookNames[j] = bookNames[i];
            j++;
        }
    }

    bookIDs[j] = bookIDs[n - 1];
    bookNames[j] = bookNames[n - 1];
    j++;

    cout << "\nCleaned List (Duplicates Removed):" << endl;
    for (int i = 0; i < j; i++) {
        cout << bookIDs[i] << " - " << bookNames[i] << endl;
    }

    return 0;
}
