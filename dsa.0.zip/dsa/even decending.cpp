
#include <iostream>
#include <vector>
using namespace std;

vector<int> mergeEvenNumbersDescending(const vector<int>& arr1, const vector<int>& arr2) {
    int i = arr1.size() - 1; // start from end of arr1
    int j = arr2.size() - 1; // start from end of arr2
    vector<int> merged;

    // Merge only even numbers in descending order
    while (i >= 0 && j >= 0) {
        if (arr1[i] >= arr2[j]) {
            if (arr1[i] % 2 == 0) {
                merged.push_back(arr1[i]);
            }
            i--;
        } else {
            if (arr2[j] % 2 == 0) {
                merged.push_back(arr2[j]);
            }
            j--;
        }
    }

    // Remaining elements from arr1
    while (i >= 0) {
        if (arr1[i] % 2 == 0) {
            merged.push_back(arr1[i]);
        }
        i--;
    }

    // Remaining elements from arr2
    while (j >= 0) {
        if (arr2[j] % 2 == 0) {
            merged.push_back(arr2[j]);
        }
        j--;
    }

    return merged; // already descending
}

int main() {
    vector<int> arr1 = {1, 2, 5, 8, 11};
    vector<int> arr2 = {3, 4, 7, 9, 10, 15};

    vector<int> merged = mergeEvenNumbersDescending(arr1, arr2);

    cout << "Merged Even Array (Descending): ";
    for (int num : merged) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}
