
#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    float heights[n];
    for(int i = 0; i < n; i++) {
        cin >> heights[i];
    }


    float highest = -1, secondHighest = -1;

    for(int i = 0; i < n; i++) {
        float ratio = 60 / heights[i];

        if(ratio > highest) {
            secondHighest = highest;
            highest = ratio;
        } else if(ratio > secondHighest && ratio != highest) {
            secondHighest = ratio;
        }
    }


    cout.precision(2);
    cout << fixed << highest << " " << secondHighest << endl;

    return 0;
}
