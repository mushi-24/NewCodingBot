#include <iostream>
using namespace std;
struct Node{
char ch;
int count;
Node*left,*right;
Node (char c,int n){
    char ch;
    coun=n;
left  = right=nullptr;

};
struct Compare{
bool operator{}(NOde*a,node*b){
return a-> coun->b};

};
void printCodes(Node*root,string code )
{
    if (!root) return;
    if(!root->left&& !root->right){
        cout<<root->ch<<":"<<code<<end1;
        return;
    }

    printCodes (root->left,code+"0");
    printCodes (root->right,code+"1");

}

int main()
{
     string text ="I love baust cse"
     map<char,int>mp;
     for (char c : text) {
        if (c != ' ')
            mp[c]++;
    }
}
priority queue<Node*,vector<Node*>,Compare>pq;
for (auto it: mp){
    pq.push(new Node(it.first,it.second));
    while( pq.size()>1){
        Node*left=pq.top();
        pq.pop();
        Node*right =pq.top();
        pq.pop();
        Node * merged =new Node('s',left->coun+right->coun) ;
        merged->left=left;
        merged->right=right;
        pq.push(merged);

        Node*root =pq.top();
        cout<<huffman coding is :"<<end1 ;
        printcodes(root,"");
    }
}
