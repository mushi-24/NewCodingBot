#include<bits/stdc++.h>
using namespace std;

int main() {
    priority_queue<int, vector<int>, greater<int>> q;

    int n;
    cin >> n;
    for(int i = 0; i < n; i++) {
        int a;
        cin >> a;
        q.push(a);
    }

    int payment = 0;
    while(q.size() != 1) {
        int a, b;
        a = q.top();
        q.pop();
        b = q.top();
        q.pop();
        q.push(a + b);
        payment = payment + (a + b);
    }
    cout << payment;
    return 0;
}
