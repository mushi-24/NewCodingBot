#include <iostream>
#include<vector>
using namespace std;

struct job
{
  int main()
  {
  int n;
  cout<<"enter number of jobs:";


  sort jobs begin(),jobs end(),compare;

  cout<<"jobs are:\n";
  for(int i=0; i<n;i++;){

  }

  };


