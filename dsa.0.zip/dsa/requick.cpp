#include <iostream>
using namespace std;

// Partition function (pivot = first element)
int partition(int arr[], int low, int high) {
    int pivot = arr[low];   // Choose first element as pivot
    int i = low + 1;        // Start comparing from next element
    int j = high;

    while (true) {
        // Move i forward while arr[i] <= pivot
        while (i <= high && arr[i] <= pivot)
            i++;

        // Move j backward while arr[j] > pivot
        while (j >= low && arr[j] > pivot)
            j--;

        if (i < j)
            swap(arr[i], arr[j]); // Swap out-of-place elements
        else
            break;
    }
    swap(arr[low], arr[j]); // Place pivot in correct position
    return j; // Pivot index
}

// Recursive QuickSort
void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);

        // Recursively sort left and right subarrays
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Main function
int main() {
    int arr[] = {29, 10, 14, 37, 13, 5, 72, 8};
    int n = sizeof(arr) / sizeof(arr[0]);

    cout << "Original array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;

    quickSort(arr, 0, n - 1);

    cout << "Sorted array using Quick Sort (First Pivot): ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;

    return 0;
}
