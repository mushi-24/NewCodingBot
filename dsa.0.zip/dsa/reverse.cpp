
##include <iostream>
using namespace std;

// Node structure for the linked list
struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

// Function to create a linked list
Node* createLinkedList(int n) {
    if (n == 0) return nullptr;

    Node* head = nullptr;
    Node* tail = nullptr;

    for (int i = 0; i < n; ++i) {
        int val;
        cin >> val;

        Node* newNode = new Node(val);

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    return head;
}

// Function to print linked list in reverse order (using recursion)
void printReverse(Node* head) {
    if (head == nullptr) return;

    printReverse(head->next);
    cout << head->data << " ";
}

// Function to delete the linked list to free memory
void deleteLinkedList(Node* head) {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

int main() {
    int n;
    cin >> n; // Read the size of the linked list

    Node* head = createLinkedList(n);

    printReverse(head);
    cout << endl;

    deleteLinkedList(head); // Free memory

    return 0;
}
