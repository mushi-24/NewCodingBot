#include<bits/stdc++.h>
using namespace std;

int main() {
    queue<int> q;
    vector<int> v;

    int n, k;
    cin >> n >> k;  // Fixed typo: changed 'cinn>>k' to 'cin >> k'

    for(int i = 0; i < n; i++) {
        int a;
        cin >> a;
        v.push_back(a);  // Fixed: added missing parenthesis
    }

    for(int i = 0; i < n; i++) {
        int b;
        cin >> b;
        q.push(b);  // Fixed: changed 'v.push(b)' to 'q.push(b)' since we want to add to queue
    }

    int time = 0;  // Fixed: changed 'timer' to 'time' for consistency
    while(!q.empty()) {  // Fixed: changed 'q.empty()!== false' to '!q.empty()'
        int x = q.front();  // Fixed: changed 'q.top()' to 'q.front()' (queues use front)
        q.pop();

        if(v[x] > 1) {  // Fixed: added missing parenthesis and fixed bracket
            v[x] = v[x] - 1;  // Fixed: changed 'v[x]=v[x-1]' to 'v[x] = v[x] - 1'
            q.push(x);  // Fixed: added what to push into the queue
        }
        else {
            v[x] = v[x] - 1;  // This line seems redundant as we're breaking next
            if(x == k)  // Fixed: removed semicolon after if condition
                break;
        }
        time = time + 1;  // Fixed: changed 'timer' to 'time'
    }

    cout << time;  // Fixed: changed 'payment' to 'time'
    return 0;
}
