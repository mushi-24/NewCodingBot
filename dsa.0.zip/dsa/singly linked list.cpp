
##include <iostream>
using namespace std;

struct Node {
    int data,Node* next,



 if (n == 0) return nullptr;

    Node* head = nullptr;
    Node* tail = nullptr;

    for (int i = 0; i < n; ++i) {
        int val;
        cin >> val;

        Node* newNode = new Node(val);

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    return head;
}
void printReverse(Node* head) {
    if (head == nullptr) return;

    printReverse(head->next);
    cout << head->data <"
    void deleteLinkedList(Node* head) {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
