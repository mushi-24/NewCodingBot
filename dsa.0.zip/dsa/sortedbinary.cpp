
#include <iostream>
#include <vector>
using namespace std;

int findInsertPosition(const vector<int>& arr, int x) {
    int left = 0;
    int right = arr.size() - 1;
    int result = arr.size(); // Default position if x is larger than all elements

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] >= x) {
            result = mid;
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    return result;
}

int main() {
    int n, x;
    cin >> n >> x;

    vector<int> arr(n);
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }

    int position = findInsertPosition(arr, x);
    cout << position << endl;

    return 0;
}
